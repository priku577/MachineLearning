# NewsScraper - Scrape any newspaper automatically
This is a simple python script for automatically scraping the most recent articles from any news-site.
Just add the websites you want to scrape to `NewsPapers.json` and the script will go through
and scrape each site listed in the file.

For more info read comments in `NewsScraper.py`.

## Libraries
This script uses the following libraries:

https://github.com/codelucas/newspaper

https://github.com/kurtmckee/feedparser
